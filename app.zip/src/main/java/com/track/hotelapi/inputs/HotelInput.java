package com.track.hotelapi.inputs;

import lombok.*;
@Value
public class HotelInput{
    String name, prefecture;
}