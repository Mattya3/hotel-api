package com.track.hotelapi.inputs;

import lombok.*;
@Value
public class RoomInput{
    String name;
}